const MongoClient = require("mongodb").MongoClient;

MongoClient.connect("mongodb://localhost:27017/School",(error,client)=>{
if (error){
    return console.log("connection err")
}
console.log("Connected Sucessfully");

const db = client.db ("School");
db.collection("col").find({ "Date": { $eq: 2023-11-10 } }).toArray((error, result) => {
    if (error) {
        return console.log(error);
    }
    console.log(result);
});
client.close()
});
