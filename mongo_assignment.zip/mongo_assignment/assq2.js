const MongoClient = require("mongodb").MongoClient;

MongoClient.connect("mongodb://localhost:27017/college",(error,client)=>{
if (error){
    return console.log("connection err")
}
console.log("Connected Sucessfully");

const db = client.db ("college");
db.collection("class").updateMany({
    submission:0
},{
    $set:{
        Grade:"C"
    }
},{
    returnOriginal:false
}).then ((result)=>{
    console.log(result);
});
client.close()
});
