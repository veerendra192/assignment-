const MongoClient = require("mongodb").MongoClient;

MongoClient.connect("mongodb://localhost:27017/college",(error,client)=>{
if (error){
    return console.log("connection err")
}
console.log("Connected Sucessfully");

const db = client.db ("college");
db.collection("class").find({ submission: 1 }).toArray((error, result) => {
    if (error) {
        return console.log("not found .", error);
    }
    console.log(result);
});
client.close()
});
