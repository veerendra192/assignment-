const MongoClient = require("mongodb").MongoClient;

MongoClient.connect("mongodb://localhost:27017/college",(error,client)=>{
if (error){
    return console.log("connection err")
}
console.log("Connected Sucessfully");

const db = client.db ("college");
const newStudent = {
    Id: 812,
    Email: "e@e.com",
    Name: "Rick",
    submission: 1,
    Grade: "N.A"
};

db.collection("class").insertOne(newStudent, (error, result) => {
    if (error) {
        return console.log("Unable to insert.", error);
    }
    console.log("inserted.", result.ops);
});

client.close();
});